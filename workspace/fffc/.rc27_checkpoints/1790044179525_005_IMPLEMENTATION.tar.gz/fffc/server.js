const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'users.json');

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(__dirname));

// Garantir diretório de dados
if (!fs.existsSync(path.join(__dirname, 'data'))) {
    fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
}

// Inicializar dados padrão se não existirem
if (!fs.existsSync(DATA_FILE)) {
    const initialProfiles = [
        { id: 'p1', name: 'Mariana Silva', age: 24, gender: 'Feminino', photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=600&q=80', bio: 'Apaixonada por viagens, café e boa música ☕✈️' },
        { id: 'p2', name: 'Lucas Gabriel', age: 27, gender: 'Masculino', photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80', bio: 'Desenvolvedor de software & viciado em churrasco 💻🥩' },
        { id: 'p3', name: 'Camila Souza', age: 22, gender: 'Feminino', photo: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&q=80', bio: 'Fotógrafa, gatinhos e sunsets 🌅🐈' },
        { id: 'p4', name: 'Bruno Henrique', age: 29, gender: 'Masculino', photo: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=600&q=80', bio: 'Atleta, crossfit e trilhas nos finais de semana 🏋️‍♂️⛰️' }
    ];
    fs.writeFileSync(DATA_FILE, JSON.stringify(initialProfiles, null, 2));
}

// Rotas API REST
app.get('/api/profiles', (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao ler perfis' });
    }
});

app.post('/api/profiles', (req, res) => {
    try {
        const { name, age, gender, photo, bio } = req.body;
        if (!name || !age || !photo) {
            return res.status(400).json({ error: 'Nome, idade e foto são obrigatórios.' });
        }

        const profiles = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        const newProfile = {
            id: 'user_' + Date.now(),
            name,
            age: parseInt(age),
            gender: gender || 'Outro',
            photo,
            bio: bio || ''
        };

        profiles.push(newProfile);
        fs.writeFileSync(DATA_FILE, JSON.stringify(profiles, null, 2));
        res.status(201).json(newProfile);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao criar perfil' });
    }
});

app.put('/api/profiles/:id', (req, res) => {
    try {
        const { id } = req.params;
        const { name, age, gender, photo, bio } = req.body;
        const profiles = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        const index = profiles.findIndex(p => p.id === id);

        if (index === -1) {
            return res.status(404).json({ error: 'Perfil não encontrado.' });
        }

        profiles[index] = {
            id,
            name: name || profiles[index].name,
            age: age ? parseInt(age) : profiles[index].age,
            gender: gender || profiles[index].gender,
            photo: photo || profiles[index].photo,
            bio: bio !== undefined ? bio : profiles[index].bio
        };

        fs.writeFileSync(DATA_FILE, JSON.stringify(profiles, null, 2));
        res.json(profiles[index]);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao atualizar perfil' });
    }
});

app.delete('/api/profiles/:id', (req, res) => {
    try {
        const { id } = req.params;
        let profiles = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        const initialLength = profiles.length;
        profiles = profiles.filter(p => p.id !== id);

        if (profiles.length === initialLength) {
            return res.status(404).json({ error: 'Perfil não encontrado.' });
        }

        fs.writeFileSync(DATA_FILE, JSON.stringify(profiles, null, 2));
        res.json({ message: 'Perfil deletado com sucesso.' });
    } catch (err) {
        res.status(500).json({ error: 'Erro ao deletar perfil' });
    }
});

if (require.main === module) {
    app.listen(PORT, () => {
        console.log(`Servidor AmorMatch rodando na porta ${PORT}`);
    });
}

module.exports = app;
