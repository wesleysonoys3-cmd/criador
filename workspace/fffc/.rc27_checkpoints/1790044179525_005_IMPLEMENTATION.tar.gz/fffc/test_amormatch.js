const fs = require('fs');
const assert = require('assert');

console.log('Iniciando testes do site de relacionamento AmorMatch...');

// Verificar se index.html existe
assert(fs.existsSync('index.html'), 'O arquivo index.html deve existir na raiz.');

const htmlContent = fs.readFileSync('index.html', 'utf8');

// Verificar elementos essenciais
assert(htmlContent.includes('AmorMatch'), 'O título/marca AmorMatch deve estar presente.');
assert(htmlContent.includes('screen-auth'), 'A tela de autenticação deve estar presente.');
assert(htmlContent.includes('screen-discover'), 'A tela de descoberta (swipe) deve estar presente.');
assert(htmlContent.includes('screen-matches'), 'A tela de matches/chat deve estar presente.');
assert(htmlContent.includes('screen-profile'), 'A tela de perfil deve estar presente.');
assert(htmlContent.includes('AmorMatchApp'), 'A classe principal da aplicação JavaScript deve estar presente.');
assert(htmlContent.includes('localStorage'), 'O suporte a LocalStorage deve estar presente para persistência de contas e fotos.');

console.log('✅ Todos os testes estruturais e funcionais passaram com sucesso!');
