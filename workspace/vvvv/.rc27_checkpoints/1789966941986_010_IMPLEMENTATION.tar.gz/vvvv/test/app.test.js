const request = require('supertest');
const app = require('../server');

describe('Sistema Web - Testes Automatizados', () => {
  test('GET / deve retornar a página HTML inicial com status 200', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Sistema Web com Botão de Teste');
    expect(response.text).toContain('Executar Botão de Teste');
  });

  test('GET /api/test deve retornar sucesso e mensagem em JSON', async () => {
    const response = await request(app).get('/api/test');
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('success', true);
    expect(response.body).toHaveProperty('message');
    expect(typeof response.body.message).toBe('string');
  });
});
