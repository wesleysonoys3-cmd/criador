const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Rota da Página Inicial
app.get('/', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Web com Botão de Teste</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-50 min-h-screen flex flex-col items-center justify-center p-6">
    <div class="max-w-md w-full bg-white rounded-xl shadow-lg p-8 text-center border border-slate-100">
        <h1 class="text-2xl font-bold text-slate-800 mb-2">Bem-vindo!</h1>
        <p class="text-slate-600 mb-6">Clique no botão abaixo para executar o teste do sistema.</p>
        
        <button id="testButton" onclick="executarTeste()" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-lg transition duration-200 shadow-md">
            Executar Botão de Teste
        </button>

        <div id="resultBox" class="mt-6 hidden p-4 rounded-lg text-sm font-medium"></div>
    </div>

    <script>
        async function executarTeste() {
            const btn = document.getElementById('testButton');
            const box = document.getElementById('resultBox');
            
            btn.disabled = true;
            btn.textContent = 'Testando...';
            
            try {
                const response = await fetch('/api/test');
                const data = await response.json();
                
                box.classList.remove('hidden', 'bg-red-100', 'text-red-700');
                box.classList.add('bg-emerald-100', 'text-emerald-800');
                box.textContent = data.message || 'Teste realizado com sucesso!';
            } catch (err) {
                box.classList.remove('hidden', 'bg-emerald-100', 'text-emerald-800');
                box.classList.add('bg-red-100', 'text-red-700');
                box.textContent = 'Erro ao executar teste de conexão.';
            } finally {
                btn.disabled = false;
                btn.textContent = 'Executar Botão de Teste';
            }
        }
    </script>
</body>
</html>`);
});

// Endpoint de Teste API
app.get('/api/test', (req, res) => {
  res.json({ success: true, message: 'Sucesso! O sistema web e o botão de teste estão funcionando perfeitamente.' });
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
  });
}

module.exports = app;
